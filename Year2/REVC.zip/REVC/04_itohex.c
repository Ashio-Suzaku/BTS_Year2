/* ----------------------------------------------------------------------------
| BTS CIEL-IR Lycée La Fayette - 0770920G
+ ----------------------------------------------------------------------------
|
| Nom : 04_itohex.c
|
| Projet : itohex
| Sujet : convertir un int en hexa
|
| Auteur : OULD CADI-RAVILY Sacha
| Version : 1.0
| Création : 5/09/2025
| Mise à jour : 12/09/2025
|
| Contraintes : aucune ( C Standard )
| Fabrication : gcc -Wall -o /home/Documents/c_language/Year2/REVC/04_itohex 04_itohex.c
+ ------------------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>

char* itohex(long val, int lg);

int main(int argc, char* argv[]) {

    if ( argc < 3 ) return -1;
    puts(itohex(atol(argv[1]), atoi(argv[2])));

    return 0;

}

char* itohex(long val, int lg) {

    static char hexValue[9] = "00000000";

    if (lg > 8) lg = 8;
    if (lg < 1) lg = 1;

    int i;
    for (i = 7; i >= 0; i--) {

        ((val & 0xF) > 9) ? (hexValue[i] = (val & 0xF)+55) : (hexValue[i] = (val & 0xF)+48);
        val >>= 4;
        
    }

    return hexValue + 8 - lg;

}